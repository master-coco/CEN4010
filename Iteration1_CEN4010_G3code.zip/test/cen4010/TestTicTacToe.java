package cen4010;
import static org.junit.jupiter.api.Assertions.*;

import javax.swing.JButton;

import org.junit.jupiter.api.Test;

class TestTicTacToe {

	@Test
	void TestWinConditionPlayer1() {
		TicTacToe tictactoe = new TicTacToe();
		tictactoe.initializeGameStateWin(1);
		tictactoe.click();
		
		boolean expectedPlayer2 = false;
		boolean actualPlayer2 = tictactoe.didPlayer2Win();

		assertEquals(expectedPlayer2, actualPlayer2);
		
		boolean expectedPlayer1 = true;
		boolean actualPlayer1 = tictactoe.didPlayer1Win();
		
		assertEquals(expectedPlayer1, actualPlayer1);
	}
	
	@Test
	void TestWinConditionPlayer2() {
		TicTacToe tictactoe = new TicTacToe();
		tictactoe.initializeGameStateWin(2);
		tictactoe.click();
		
		boolean expectedPlayer2 = true;
		boolean actualPlayer2 = tictactoe.didPlayer2Win();

		assertEquals(expectedPlayer2, actualPlayer2);
		
		boolean expectedPlayer1 = false;
		boolean actualPlayer1 = tictactoe.didPlayer1Win();
		
		assertEquals(expectedPlayer1, actualPlayer1);
	}

}
