package cen4010;

public class Coordinate {

}
