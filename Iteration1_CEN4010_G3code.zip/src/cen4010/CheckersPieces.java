package cen4010;

public class CheckersPieces {

	private int x, y;
	boolean color; //true is red false is black
	Coordinate[] legalMoves = new Coordinate[3];
	
	public Coordinate generateLegalMoves() {
		Coordinate coordinate = new Coordinate();
		boolean flag = false;
		while(!flag) {
		if(this.x == 0) {
			
		}
		}
		return coordinate;
	}
	
	public void move() {
		
	}
}
