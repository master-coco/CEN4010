package cen4010;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class CustomJFrame {
	public JButton[] buttonArray = new JButton[7];
	
	public CustomJFrame() {
	JFrame frame = new JFrame();
	frame.setSize(800,800);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	JPanel main = new JPanel();
	GridBagLayout layout = new GridBagLayout();
	main.setLayout(layout);
	GridBagConstraints c = new GridBagConstraints();
	
	c.insets = new Insets(5,5,5,5);
	c.anchor = GridBagConstraints.FIRST_LINE_START;
	
	
	}
}
