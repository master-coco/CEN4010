package cen4010;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TicTacToe extends JFrame {
	private JButton[] buttons = new JButton[9];
	private JLabel turnStatus = new JLabel();
	private JLabel coinFlip = new JLabel();
	private JPanel menu = new JPanel();
	private boolean player1Turn = true;
	private boolean scenario = true;
	private boolean victory = false;
	private boolean player1Won = false;
	private boolean player2Won = false;
	private int turnCounter = 0;

	public TicTacToe() {
		JFrame frame = new JFrame();
		// JPanel topPanel = new JPanel();
		JPanel buttonsPanel = new JPanel();
		JPanel panelContent = new JPanel();
		// JPanel flipPanel = new JPanel();
		JPanel ticTacToePanel = new JPanel();
		JButton resetBtn = new JButton("resetBtn");
		JButton returnToMenuBtn = new JButton("returnToMenuBtn");
		frame.setSize(800, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		buttonsPanel.setLayout(new GridLayout(3, 3));

		class InnerActionListener implements ActionListener {

			/**
			 * actionPerformed will look into what exactly to do if a user hits submit or
			 * clear and carry out what was mentioned in the inner action class listener
			 * comment above.
			 * 
			 * @param e user
			 */
			@Override
			public void actionPerformed(ActionEvent e) {
				if (isDraw()) {
					turnStatus.setText("It's a draw!");
				}
				JButton specificButton = (JButton) e.getSource();// Differentiating what to do if either button is
				// pressed.
				String name = specificButton.getName();
				if (name != returnToMenuBtn.getName() || name != resetBtn.getName()) {
					if (turnCounter <= 8) {
						turnCounter++;
						for (int i = 0; i < 9; i++) {
							if (name == buttons[i].getName() && player1Turn && buttons[i].getText() == "") {
								buttons[i].setText("X");
							} else if (name == buttons[i].getName() && !player1Turn && buttons[i].getText() == "") {
								buttons[i].setText("O");
							}
						}
						if (name != returnToMenuBtn.getName() || name != resetBtn.getName()) {
							if (player1Turn) {
								turnStatus.setText("It is player 1's turn");
								player1Turn = false;
							} else if (!player1Turn) {
								turnStatus.setText("It is player 2's turn");
								player1Turn = true;
							}
						}

						winConditionCheck();
					} else {
						turnCounter = 0;
						turnStatus.setText("It is a draw!");
						reset();
					}
				}

				if (name == returnToMenuBtn.getName()) {

				}
				if (name == resetBtn.getName()) {
					reset();
				}
			}

			public void winConditionCheck() {
				if (buttons[0].getText() == "O" && buttons[1].getText() == "O" && buttons[2].getText() == "O") {
					playerOneWon(false);
					setColor(0, 1, 2);
				}
				if (buttons[3].getText() == "O" && buttons[4].getText() == "O" && buttons[5].getText() == "O") {
					playerOneWon(false);
					setColor(3, 4, 5);
				}
				if (buttons[6].getText() == "O" && buttons[7].getText() == "O" && buttons[8].getText() == "O") {
					playerOneWon(false);
					setColor(6, 7, 8);
				}
				if (buttons[0].getText() == "O" && buttons[4].getText() == "O" && buttons[8].getText() == "O") {
					playerOneWon(false);
					setColor(0, 4, 8);
				}
				if (buttons[2].getText() == "O" && buttons[4].getText() == "O" && buttons[6].getText() == "O") {
					playerOneWon(false);
					setColor(2, 4, 6);
				}
				if (buttons[0].getText() == "O" && buttons[3].getText() == "O" && buttons[6].getText() == "O") {
					playerOneWon(false);
					setColor(0, 3, 6);
				}
				if (buttons[1].getText() == "O" && buttons[4].getText() == "O" && buttons[7].getText() == "O") {
					playerOneWon(false);
					setColor(1, 4, 7);
				}
				if (buttons[2].getText() == "O" && buttons[5].getText() == "O" && buttons[8].getText() == "O") {
					playerOneWon(false);
					setColor(2, 5, 8);
				}

				// Player 2 scenarios from now on

				if (buttons[0].getText() == "X" && buttons[1].getText() == "X" && buttons[2].getText() == "X") {
					playerOneWon(true);
					setColor(0, 1, 2);
				}
				if (buttons[3].getText() == "X" && buttons[4].getText() == "X" && buttons[5].getText() == "X") {
					playerOneWon(true);
					setColor(3, 4, 5);
				}
				if (buttons[6].getText() == "X" && buttons[7].getText() == "X" && buttons[8].getText() == "X") {
					playerOneWon(true);
					setColor(6, 7, 8);
				}
				if (buttons[0].getText() == "X" && buttons[4].getText() == "X" && buttons[8].getText() == "X") {
					playerOneWon(true);
					setColor(0, 4, 8);
				}
				if (buttons[2].getText() == "X" && buttons[4].getText() == "X" && buttons[6].getText() == "X") {
					playerOneWon(true);
					setColor(2, 4, 6);
				}
				if (buttons[0].getText() == "X" && buttons[3].getText() == "X" && buttons[6].getText() == "X") {
					playerOneWon(true);
					setColor(0, 3, 6);
				}
				if (buttons[1].getText() == "X" && buttons[4].getText() == "X" && buttons[7].getText() == "X") {
					playerOneWon(true);
					setColor(1, 4, 7);
				}
				if (buttons[2].getText() == "X" && buttons[5].getText() == "X" && buttons[8].getText() == "X") {
					playerOneWon(true);
					setColor(2, 5, 8);
				}

			}

			public void setColor(int first, int second, int third) {
				buttons[first].setBackground(new Color(124, 252, 0));
				buttons[second].setBackground(new Color(124, 252, 0));
				buttons[third].setBackground(new Color(124, 252, 0));
				buttons[first].setOpaque(true);
				buttons[second].setOpaque(true);
				buttons[third].setOpaque(true);
			}

			public boolean isDraw() {
				return turnCounter == 9 && victory == false;
			}

			public boolean playerOneWon(boolean scenario) {
				if (victory == false) {
					if (scenario == true) {
						turnStatus.setText("Player one has won");
						victory = true;
						player1Won = true;
						player2Won = false;
						reset();
					} else {
						turnStatus.setText("Player two has won");
						victory = true;
						player1Won = false;
						player2Won = true;
						reset();
					}
				}
				return player1Won;
			}
		}

		InnerActionListener listener = new InnerActionListener();

		JButton button0 = new JButton();
		button0.setName("button0");
		buttons[0] = button0;
		JButton button1 = new JButton();
		button1.setName("button1");
		buttons[1] = button1;
		JButton button2 = new JButton();
		button2.setName("button2");
		buttons[2] = button2;
		JButton button3 = new JButton();
		button3.setName("button3");
		buttons[3] = button3;
		JButton button4 = new JButton();
		button4.setName("button4");
		buttons[4] = button4;
		JButton button5 = new JButton();
		button5.setName("button5");
		buttons[5] = button5;
		JButton button6 = new JButton();
		button6.setName("button6");
		buttons[6] = button6;
		JButton button7 = new JButton();
		button7.setName("button7");
		buttons[7] = button7;
		JButton button8 = new JButton();
		button8.setName("button8");
		buttons[8] = button8;

		for (int i = 0; i < 9; i++) {
			buttons[i].addActionListener(listener);
		}

		turnStatus.setBounds(0, 0, 800, 100);

		turnStatus.setText("It is player 1's turn");
		turnStatus.setHorizontalAlignment(JLabel.CENTER);
		turnStatus.setName("turnStatusLabel");
		turnStatus.setFont(new Font("Papyrus", Font.BOLD, 70));
		ticTacToePanel.add(turnStatus);

		// It's a little wonky, but this shows the initial coin flip
		coinFlip.setName("coinFlipLabel");
		ticTacToePanel.add(coinFlip);

		// Adding buttons to the button panel
		buttonsPanel.add(buttons[0]);
		buttonsPanel.add(buttons[1]);
		buttonsPanel.add(buttons[2]);
		buttonsPanel.add(buttons[3]);
		buttonsPanel.add(buttons[4]);
		buttonsPanel.add(buttons[5]);
		buttonsPanel.add(buttons[6]);
		buttonsPanel.add(buttons[7]);
		buttonsPanel.add(buttons[8]);
		// Placing button panel on frame

		buttonsPanel.setBounds(0, 100, 800, 625);

		resetBtn.addActionListener(listener);
		resetBtn.setText("reset");
		resetBtn.setBounds(0, 725, 100, 50);

		returnToMenuBtn.setText("Return to Menu");

		frame.add(turnStatus, BorderLayout.NORTH);
		frame.add(resetBtn);
		frame.add(buttonsPanel);

		frame.setVisible(true);
	}
	/**
	 * reset method resets the text e.g. the X and O's and resets the green filter
	 */
	public void reset() {
		for (int i = 0; i < 9; i++) {
			buttons[i].setText("");
		}
		for (int i = 0; i < 9; i++) {
			buttons[i].setBackground(new Color(255, 255, 255));
		}
		player1Turn = true;
		if (victory != false) {
			turnStatus.setText("It is player 1's turn");
		}
		turnCounter = 0;
	}

	public void click() {
		buttons[4].doClick();
	}

	public void initializeGameStateWin(int player) {
		if (player == 1) {
			buttons[0].setText("X");
			buttons[1].setText("X");
			buttons[2].setText("X");
		} else if (player == 2) {
			buttons[0].setText("O");
			buttons[1].setText("O");
			buttons[2].setText("O");
		}
	}

	public boolean didPlayer1Win() {
		return player1Won;
	}

	public boolean didPlayer2Win() {
		return player2Won;
	}
}