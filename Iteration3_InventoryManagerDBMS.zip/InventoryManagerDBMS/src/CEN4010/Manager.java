package CEN4010;

public class Manager extends Employee {
	protected String managerial = "Y";
	
	Manager(String employeeID, String firstName, String lastName, String managerial){
		super(employeeID, firstName, lastName, managerial);
	}

	@Override
	public String toString() {
		return "Manager [employeeID=" + employeeID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", managerial=" + managerial + "]";
	}
}
