package CEN4010;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import CEN4010.AbstractMenuFactory.ViewPacket;

public class CustomJFrame extends JFrame {
	// IMPORTANT: ANY COMMENTED OUT CODE IS MOST LIKELY FOR THE SCENARIO OF IF WE DO
	// AN EVENT PLANNER PROGRAM
	private HashMap<String, String> loginCredentials = new HashMap<>();
	private JPanel cards;
	private JPanel signInPanel;
	private JPanel signUpPanel;
	private JPanel homePanel;
	// These elements are for the sign in panel
	private JButton signInBtn = new JButton("Sign in");
	// These elements are for the signup page
	private JButton signUpBtn = new JButton("Sign Up"); // make sure that this button takes to home page!
	private JButton createAccountBtn = new JButton("Sign Up");
	private JButton cancelBtn = new JButton("Back to Sign In");
	//Generic model for action listeners
	DefaultTableModel updateModel = new DefaultTableModel();
	//JFrame icon
//	ImageIcon legoIcon = new ImageIcon(getClass().getClassLoader().getResource("LegoIcon.png"));
		
	public CustomJFrame() throws SQLException {
		// Initializing all the panels
		JFrame frame = new JFrame("Lego Inventory DBMS");
		cards = new JPanel(new CardLayout());
		signInPanel = new JPanel();
		homePanel = new JPanel();
		signUpPanel = new JPanel();
		JLabel usernameLabel = new JLabel("Username: ");
		JLabel passwordLabel = new JLabel("Password: ");
		JLabel employeeIDLabelSignUp = new JLabel("Employee ID: ");
		JLabel usernameLabelSignUp = new JLabel("Username: ");
		JLabel passwordLabelSignUp = new JLabel("Password: ");
		JTextField ssnFieldSignUp = new JTextField();
		JTextField usernameFieldSignUp = new JTextField();
		JTextField usernameField = new JTextField();
		JPasswordField passwordFieldSignUp = new JPasswordField();
		JPasswordField passwordField = new JPasswordField();
		// These error messages are specifically for use on the sign up page
		JLabel errorMessageSignUpLength = new JLabel(
				"The username AND password must both be individually under 20 characters long");
		JLabel errorMessageSignUpUnique = new JLabel("The username MUST be unique, please choose a new one");
		JLabel errorMessage = new JLabel("Incorrect username or password please try again");
		GridBagConstraints gbc = new GridBagConstraints();
		JScrollPane homeScrollPane = new JScrollPane();
		// JTable queriedInventory;
		CardLayout cl = (CardLayout) cards.getLayout();

		// adding all panels to the cardslayout panel
		cards.add(signInPanel, "Sign-in Page");
		cards.add(signUpPanel, "Sign-up Page");
		cards.add(homePanel, "Home Page");


		//Adding all button listeners here
		signInBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cl = (CardLayout) cards.getLayout();
				try {
					if (Database.getLogin(usernameField.getText(), String.valueOf(passwordField.getPassword()))
							&& Database.isAdmin(usernameField.getText())) {
						ManagerViewFactory adminFactory = new ManagerViewFactory();
						ViewPacket adminPacket = adminFactory.createView();
						frame.getContentPane().add(adminPacket.getCards());
						frame.validate();
						frame.setJMenuBar(adminPacket.getMenuBar());
						cl.show(cards, "Home Page");
					} else if (Database.getLogin(usernameField.getText(), String.valueOf(passwordField.getPassword()))
							&& Database.isAdmin(usernameField.getText()) == false) {
						RegularViewFactory regularFactory = new RegularViewFactory();
						ViewPacket regularPacket = regularFactory.createView();
						frame.getContentPane().add(regularPacket.getCards());
						frame.validate();
						frame.setJMenuBar(regularPacket.getMenuBar());
						cl.show(cards, "Home Page");
					} else {
						errorMessage.setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//Just in case, sets the fields to empty so no one can see
				usernameField.setText("");
				passwordField.setText("");
			}
		});
		signUpBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// CardLayout cl = (CardLayout) cards.getLayout();
				try {
					// If the user or pass is longer than 20 characters
					if (usernameFieldSignUp.getText().length() > 20
							|| String.valueOf(passwordField.getPassword()).length() > 20) {
						errorMessageSignUpLength.setVisible(true);
						errorMessageSignUpUnique.setVisible(false);
					}
					// If the user name is unique then we sign them up here
					else if (Database.uniqueUsernameAndSsn(usernameFieldSignUp.getText(), ssnFieldSignUp.getText())) {
						errorMessageSignUpLength.setVisible(false);
						errorMessageSignUpUnique.setVisible(false);
						Database.insertLogin(ssnFieldSignUp.getText(), usernameFieldSignUp.getText(),
								String.valueOf(passwordFieldSignUp.getPassword()));
						cl.show(cards, "Sign-Up Page");
					}
					// If the username is not unique
					else if (Database.uniqueUsernameAndSsn(usernameFieldSignUp.getText(),
							ssnFieldSignUp.getText()) == false) {
						errorMessageSignUpLength.setVisible(false);
						errorMessageSignUpUnique.setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		createAccountBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Sign-up Page");
			}
		});
		cancelBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Sign-in Page");
			}
		});
		// Hard coding sign in panel because it doesn't need much structure or buttons
		// to it.
		signInPanel.setLayout(null);
		usernameLabel.setBounds(300, 225, 100, 25);
		usernameField.setBounds(300, 250, 200, 25);
		passwordLabel.setBounds(300, 275, 100, 25);
		passwordField.setBounds(300, 300, 200, 25);
		signInBtn.setBounds(350, 350, 100, 50);
		createAccountBtn.setBounds(350, 400, 100, 50);
		errorMessage.setForeground(Color.red);
		errorMessage.setBounds(250, 400, 400, 25);
		errorMessage.setVisible(false);
		signInPanel.add(usernameLabel);
		signInPanel.add(passwordLabel);
		signInPanel.add(usernameField);
		signInPanel.add(passwordField);
		signInPanel.add(errorMessage);
		// Button that allows user to sign in if a verified employee
		// Add an if check later for how we decided to see if the person is an employee
		// or not
		signInPanel.add(createAccountBtn);
		signInPanel.add(signInBtn);

		// Hard coding sign up panel as well
		signUpPanel.setLayout(null);
		employeeIDLabelSignUp.setBounds(300, 175, 100, 25);
		ssnFieldSignUp.setBounds(300, 200, 200, 25);
		usernameLabelSignUp.setBounds(300, 225, 100, 25);
		usernameFieldSignUp.setBounds(300, 250, 200, 25);
		passwordLabelSignUp.setBounds(300, 275, 100, 25);
		passwordFieldSignUp.setBounds(300, 300, 200, 25);
		signUpBtn.setBounds(400, 350, 100, 50);
		cancelBtn.setBounds(300, 350, 100, 50);
		errorMessageSignUpLength.setForeground(Color.red);
		errorMessageSignUpUnique.setForeground(Color.red);
		errorMessageSignUpLength.setBounds(250, 400, 400, 25);
		errorMessageSignUpUnique.setBounds(250, 430, 400, 25);
		errorMessageSignUpUnique.setVisible(false);
		errorMessageSignUpLength.setVisible(false);
		signUpPanel.add(employeeIDLabelSignUp);
		signUpPanel.add(ssnFieldSignUp);
		signUpPanel.add(usernameLabelSignUp);
		signUpPanel.add(usernameFieldSignUp);
		signUpPanel.add(passwordLabelSignUp);
		signUpPanel.add(passwordFieldSignUp);
		signUpPanel.add(errorMessageSignUpUnique);
		signUpPanel.add(errorMessageSignUpLength);
		signUpPanel.add(cancelBtn);
		signUpPanel.add(signUpBtn);

		// Adding all buttons for the home page
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.PAGE_START;
		JLabel welcomeLabel = new JLabel("Welcome to the inventory DBMS!");
		Border welcomeBorder = BorderFactory.createRaisedBevelBorder();
		welcomeLabel.setBorder(welcomeBorder);
		homePanel.add(welcomeLabel, gbc);

		frame.getContentPane().add(cards);
		frame.pack();
		frame.setSize(800, 800);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
