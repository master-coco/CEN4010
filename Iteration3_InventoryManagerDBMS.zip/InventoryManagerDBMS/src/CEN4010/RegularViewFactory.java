package CEN4010;

import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class RegularViewFactory implements AbstractMenuFactory {
	private JScrollPane queriedInventoryScrollPane;
	private JTable queriedInventory = new JTable();
	private TableRowSorter<TableModel> sorter = new TableRowSorter<>();
	private DefaultTableModel model = new DefaultTableModel();
	private DefaultTableModel updateModel = new DefaultTableModel();
	private JPanel inventoryPanel;
	private JPanel homePanel;

	@Override
	public ViewPacket createView() throws SQLException {
		GridBagConstraints gbc = new GridBagConstraints();
		JPanel cards = new JPanel(new CardLayout());
		CardLayout cl = (CardLayout) cards.getLayout();
		homePanel = new JPanel();
		inventoryPanel = new JPanel();
		model = new DefaultTableModel();
		updateModel = new DefaultTableModel();
		queriedInventory = new JTable();
		// Inventory elements
		JButton addSetBtn = new JButton("Add/Update");
		JTextField filterField = new JTextField(20);
		JLabel filterLabel = new JLabel("Filter");
		// JMenuBar Code regular view
		JMenuBar menuBar = new JMenuBar();
		JMenu navigate = new JMenu("Navigate");
		JMenuItem home = new JMenuItem("Home");
		JMenuItem inventory = new JMenuItem("Inventory");
		JMenuItem signOut = new JMenuItem("Sign out");
		// adding listeners to menubar options
		// JMenuBar actionlisteners for regular view
		home.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Home Page");
			}
		});
		inventory.setName("Inventory Page");
		inventory.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Inventory Page");
			}
		});
		signOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		addSetBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField setNameField = new JTextField();
				JTextField setPriceField = new JTextField();
				JTextField quantityField = new JTextField();
				JTextField itemNumberField = new JTextField();
				Format dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				Date todaysDate = Calendar.getInstance().getTime();
				String date = dateFormatter.format(todaysDate);

				Object[] fields = { "Set Name: ", setNameField, "Set Price: ", setPriceField, "Quantity Received: ",
						quantityField, "Item Number: ", itemNumberField };
				JOptionPane.showConfirmDialog(null, fields, "Add Item", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE);

				try {
					Database.addToInventory(new Product(setNameField.getText(), setPriceField.getText(),
							quantityField.getText(), itemNumberField.getText(), date));
					updateTable();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					gbc.gridx = 2;
					gbc.gridy = 0;
					gbc.gridheight = 2;
					updateModel = Database.retrieveInventory();
					queriedInventory.setModel(updateModel);
					inventoryPanel.add(queriedInventoryScrollPane, gbc);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

		});
		filterField.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					updateTable();
					queriedInventory.setRowSorter(sorter);	
					if(filterField.getText()=="") {
						((TableRowSorter<TableModel>) queriedInventory.getRowSorter()).setRowFilter(null);
					}
					else {
						((TableRowSorter<TableModel>) queriedInventory.getRowSorter()).setRowFilter(RowFilter.regexFilter(filterField.getText()));
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		//Generating table for inventory page
	    model = Database.retrieveInventory();
		queriedInventory.setModel(model);
		queriedInventoryScrollPane = new JScrollPane(queriedInventory);
		queriedInventoryScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		// adding components to menubar to finalize it
		navigate.add(home);
		navigate.add(inventory);
		navigate.add(signOut);
		menuBar.add(navigate);
		// working with individual panels
		homePanel.setLayout(new GridBagLayout());
		// Adding all buttons for the home page
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.PAGE_START;
		JLabel welcomeLabel = new JLabel("Welcome to the inventory DBMS!");
		Border welcomeBorder = BorderFactory.createRaisedBevelBorder();
		welcomeLabel.setBorder(welcomeBorder);
		homePanel.add(welcomeLabel, gbc);
		// Adding buttons for Regular view inventory panel
		JPanel btnsPanel = new JPanel();
		btnsPanel.setLayout(new GridBagLayout());
		inventoryPanel.setLayout(new GridBagLayout());
		gbc.gridx = 0;
		gbc.gridy = 1;
		btnsPanel.add(addSetBtn, gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		btnsPanel.add(filterLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy = 3;
		btnsPanel.add(filterField, gbc);
		gbc.gridx = 0;
		gbc.gridy = 0;
		inventoryPanel.add(btnsPanel, gbc);
		gbc.gridx = 4;
		gbc.gridy = 0;
		gbc.gridheight = 6;
		inventoryPanel.add(queriedInventoryScrollPane, gbc);
		// adding panels to cards
		cards.add(homePanel, "Home Page");
		cards.add(inventoryPanel, "Inventory Page");

		ViewPacket regularViewPacket = new ViewPacket(menuBar, cards);
		return regularViewPacket;
	}
	
	public void updateTable() throws SQLException {
		 updateModel = Database.retrieveInventory();
		 queriedInventory.setModel(updateModel);
		 sorter = new TableRowSorter<>(updateModel);
		 queriedInventory.setRowSorter(sorter);
		 updateModel.fireTableDataChanged();
	}

}
