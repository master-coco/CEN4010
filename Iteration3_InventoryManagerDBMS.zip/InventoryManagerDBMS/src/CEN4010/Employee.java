package CEN4010;


public class Employee {
    protected String employeeID;
	protected String firstName;
	protected String lastName;
	//Easier to treat as a string and have "1" and "0" represent respective numbers/ boolean
	protected String managerial;
	
	Employee(String employeeID, String firstName, String lastName, String managerial){
		this.employeeID = employeeID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.managerial = managerial;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeID=" + employeeID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", managerial=" + managerial + "]";
	}

	public String getEmployeeID() {
		return employeeID;
	}


	public String getFirstName() {
		return firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public String getManagerial() {
		return managerial;
	}

	
}
