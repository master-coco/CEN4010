package CEN4010;

import java.sql.SQLException;

import javax.swing.JMenuBar;
import javax.swing.JPanel;

public interface AbstractMenuFactory {
	abstract ViewPacket createView() throws SQLException;
	
	class ViewPacket {
		JMenuBar menuBar = new JMenuBar();
		JPanel cards = new JPanel();
		
		public ViewPacket(JMenuBar menuBar, JPanel cards) {
			this.menuBar = menuBar;
			this.cards = cards;
		}

		public JMenuBar getMenuBar() {
			return menuBar;
		}

		public JPanel getCards() {
			return cards;
		}
	}
}
