package CEN4010;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JMenuBar;

import CEN4010.AbstractMenuFactory.ViewPacket;

public class Main {

	public static void main(String[] args) throws SQLException {
		CustomJFrame customFrame = new CustomJFrame();
	}
}
