package CEN4010;

import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ManagerViewFactory implements AbstractMenuFactory {
	// Easily update the tables with this
	private DefaultTableModel updateModel = new DefaultTableModel();
	private DefaultTableModel adminInventoryModel = new DefaultTableModel();
	private TableRowSorter<TableModel> sorter = new TableRowSorter<>();

	//
	private JScrollPane queriedEmployeesScrollPane = new JScrollPane();
	//
	private JScrollPane queriedInventoryAdminScrollPane = new JScrollPane();
	private JTable queriedInventoryAdmin = new JTable();


	@Override
	public ViewPacket createView() throws SQLException {
		JFrame frame = new JFrame();
		GridBagConstraints gbc = new GridBagConstraints();
		JPanel cards = new JPanel(new CardLayout());
		JMenuBar menuBarAdmin = new JMenuBar();
		JMenu navigateAdmin = new JMenu("Navigate");
		JMenuItem homeAdmin = new JMenuItem("Home");
		JMenuItem inventoryAdmin = new JMenuItem("Inventory");
		JMenuItem employeeAdmin = new JMenuItem("Employee");
		JMenuItem signOutAdmin = new JMenuItem("Sign out");
		CardLayout cl = (CardLayout) cards.getLayout();
		JPanel signInPanel = new JPanel();
		JPanel employeesPanelAdmin = new JPanel();
		JPanel inventoryPanel = new JPanel();
		JPanel signUpPanel = new JPanel();
		JPanel homePanel = new JPanel();
		JPanel inventoryPanelAdmin = new JPanel();
		// employee panel
		JButton addEmployeeBtn = new JButton("Add");
		JButton deleteEmployeeBtn = new JButton("Delete");
		JTable queriedEmployees = new JTable();
		// inventory admin panel
		// These elements are for the inventoryPanel in admin view
		JButton addSetBtnAdmin = new JButton("Add/Update");
		JButton deleteBtnAdmin = new JButton("Delete Row");
		JButton resetFilterBtnAdmin = new JButton("Reset");
		JLabel filterFieldLabel = new JLabel("Filter");
		JTextField filterFieldAdmin = new JTextField(20);

		cards.add(signInPanel, "Sign-in Page");
		cards.add(signUpPanel, "Sign-up Page");
		cards.add(employeesPanelAdmin, "Employees Page");
		cards.add(homePanel, "Home Page Admin");
		cards.add(inventoryPanelAdmin, "Inventory Admin Page");

		employeeAdmin.setName("Employees Page");
		employeeAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Employees Page");
			}
		});
		inventoryAdmin.setName("Admin Inventory Page");
		inventoryAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Inventory Admin Page");
			}
		});
		signOutAdmin.setName("Sign Out Admin");
		signOutAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		homeAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Home Page Admin");
			}
		});

		// Inventory admin view
		addSetBtnAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField setNameField = new JTextField();
				JTextField setPriceField = new JTextField();
				JTextField quantityField = new JTextField();
				JTextField itemNumberField = new JTextField();
				Format dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				Date todaysDate = Calendar.getInstance().getTime();
				String date = dateFormatter.format(todaysDate);

				Object[] fields = { "Set Name: ", setNameField, "Set Price: ", setPriceField, "Quantity Received: ",
						quantityField, "Item Number: ", itemNumberField };
				JOptionPane.showConfirmDialog(null, fields, "Add Item", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE);

				try {
					Database.addToInventory(new Product(setNameField.getText(), setPriceField.getText(),
							quantityField.getText(), itemNumberField.getText(), date));
					updateTable();

				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

		});
		deleteBtnAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = queriedInventoryAdmin.getSelectedRow();
				if (row != -1) {
					int column = 1;
					int rowValue = Integer.parseInt(queriedInventoryAdmin.getValueAt(row, column).toString());
					try {
						queriedInventoryAdmin.removeRowSelectionInterval(row, column);
						Database.deleteSet(rowValue);
						updateTable();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		filterFieldAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					updateTable();
					queriedInventoryAdmin.setRowSorter(sorter);	
					if(filterFieldAdmin.getText()=="") {
						((TableRowSorter<TableModel>) queriedInventoryAdmin.getRowSorter()).setRowFilter(null);
					}
					else {
						((TableRowSorter<TableModel>) queriedInventoryAdmin.getRowSorter()).setRowFilter(RowFilter.regexFilter(filterFieldAdmin.getText()));
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		// Employees button listeners being added
		addEmployeeBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField firstNameField = new JTextField();
				JTextField lastNameField = new JTextField();
				JTextField employeeIDField = new JTextField();
				JTextField managerialField = new JTextField();

				Object[] fields = { "First Name: ", firstNameField, "Last Name: ", lastNameField, "Employee ID: ",
						employeeIDField, "Manager (Y/N)", managerialField };

				JOptionPane.showConfirmDialog(null, fields, "Add Employee", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE);
				try {
					if (managerialField.getText() == "Y") {
						Database.addEmployee(new Manager(employeeIDField.getText(), firstNameField.getText(),
								lastNameField.getText(), managerialField.getText()));
					} else {
						Database.addEmployee(new Employee(employeeIDField.getText(), firstNameField.getText(),
								lastNameField.getText(), managerialField.getText()));
					}
					updateModel = Database.retrieveEmployees();
					queriedEmployees.setModel(updateModel);
					employeesPanelAdmin.add(queriedEmployeesScrollPane);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

		});
		deleteEmployeeBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = queriedEmployees.getSelectedRow();
				if (row != -1) {
					int column = 0;
					String rowValue = queriedEmployees.getValueAt(row, column).toString();
					try {
						Database.deleteEmployee(rowValue);
						updateModel = Database.retrieveEmployees();
						queriedEmployees.setModel(updateModel);
						employeesPanelAdmin.add(queriedEmployeesScrollPane);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				}
			}
		});

		// Add menu options to menubar
		navigateAdmin.add(homeAdmin);
		navigateAdmin.add(employeeAdmin);
		navigateAdmin.add(inventoryAdmin);
		navigateAdmin.add(signOutAdmin);

		// finalize the menubar
		menuBarAdmin.add(navigateAdmin);

		homePanel.setLayout(new GridBagLayout());

		// setting up welcome page/ home page for admin
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		JLabel welcomeLabel = new JLabel("Welcome to the inventory DBMS!");
		Border welcomeBorder = BorderFactory.createRaisedBevelBorder();
		welcomeLabel.setBorder(welcomeBorder);
		homePanel.add(welcomeLabel, gbc);

		// Creating table for employee page
		DefaultTableModel employeeModel = Database.retrieveEmployees();
		queriedEmployees.setModel(employeeModel);
		queriedEmployeesScrollPane = new JScrollPane(queriedEmployees);
		queriedEmployeesScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		// employee page for admin
		JPanel employeesPanelAdminBtnPanel = new JPanel();
		GridBagConstraints employeeBtnGbc = new GridBagConstraints();
		employeesPanelAdminBtnPanel.setLayout(new GridBagLayout());
		employeesPanelAdmin.setLayout(new GridBagLayout());
		employeeBtnGbc.gridx = 0;
		employeeBtnGbc.gridy = 0;
		employeesPanelAdminBtnPanel.add(addEmployeeBtn, employeeBtnGbc);
		employeeBtnGbc.gridx = 0;
		employeeBtnGbc.gridy = 1;
		employeesPanelAdminBtnPanel.add(deleteEmployeeBtn, employeeBtnGbc);
		gbc.gridx = 0;
		gbc.gridy = 0;
		employeesPanelAdmin.add(employeesPanelAdminBtnPanel, gbc);
		gbc.gridx = 4;
		gbc.gridy = 0;
		employeesPanelAdmin.add(queriedEmployeesScrollPane, gbc);

		// Admin view inventory panel
		adminInventoryModel = Database.retrieveInventory();
		queriedInventoryAdmin.setModel(adminInventoryModel);
		queriedInventoryAdminScrollPane = new JScrollPane(queriedInventoryAdmin);
		queriedInventoryAdminScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		JPanel inventoryAdminBtnPanel = new JPanel();
		GridBagConstraints adminBtnGbc = new GridBagConstraints();

		inventoryAdminBtnPanel.setLayout(new GridBagLayout());
		adminBtnGbc.gridx = 0;
		adminBtnGbc.gridy = 0;
		adminBtnGbc.anchor = GridBagConstraints.CENTER;
		inventoryAdminBtnPanel.add(addSetBtnAdmin, adminBtnGbc);
		adminBtnGbc.gridx = 0;
		adminBtnGbc.gridy = 1;
		inventoryAdminBtnPanel.add(deleteBtnAdmin, adminBtnGbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		inventoryAdminBtnPanel.add(filterFieldLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy = 3;
		inventoryAdminBtnPanel.add(filterFieldAdmin, gbc);
		gbc.gridx = 0;
		gbc.gridy = 0;
		inventoryPanelAdmin.add(inventoryAdminBtnPanel, gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.gridheight = 2;
		inventoryPanelAdmin.add(queriedInventoryAdminScrollPane, gbc);

		ViewPacket adminViewPacket = new ViewPacket(menuBarAdmin, cards);
		return adminViewPacket;
	}
	
	public void updateTable() throws SQLException {
		 updateModel = Database.retrieveInventory();
		 queriedInventoryAdmin.setModel(updateModel);
		 sorter = new TableRowSorter<>(updateModel);
		 queriedInventoryAdmin.setRowSorter(sorter);
		 updateModel.fireTableDataChanged();
	}
}
