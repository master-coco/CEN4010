package CEN4010;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;

public class Database {
	// Generic database class
	public static Boolean isAdmin(String username) throws SQLException {
		int managerialInt;
		Boolean managerial;
		Connection conn = connection();
		PreparedStatement pstmt = conn.prepareStatement(
				"SELECT MANAGERIAL FROM EMPLOYEE INNER JOIN LOGIN ON EMPLOYEE.EMPLOYEEID = LOGIN.EMPLOYEE WHERE LOGIN.USERNAME = '"
						+ username + "'");
		ResultSet rs = pstmt.executeQuery();
		rs.next();
		managerialInt = Integer.parseInt(rs.getString(1));
		if (managerialInt == 1) {
			managerial = true;
		} else {
			managerial = false;
		}
		conn.close();
		return managerial;
	}

	public static void addEmployee(Employee employee) throws SQLException {
		PreparedStatement pstmt;
		Connection conn = connection();
		String passedEmployeeID = employee.getEmployeeID();
		String passedFirstName = employee.getFirstName();
		String passedLastName = employee.getLastName();
		String passedManagerial = employee.getManagerial();

		// Logic to turn the Y/N response to 1/0 in database, may review how we store
		// the representation of manager or not
		if (passedManagerial.equals("Y")) {
			passedManagerial = "1";
		} else {
			passedManagerial = "0";
		}

		pstmt = conn.prepareStatement(
				"INSERT INTO EMPLOYEE(EMPLOYEEID, FIRSTNAME, LASTNAME, MANAGERIAL) " + "VALUES (?,?,?,?)");
		pstmt.setString(1, passedEmployeeID);
		pstmt.setString(2, passedFirstName);
		pstmt.setString(3, passedLastName);
		pstmt.setString(4, passedManagerial);
		// Logic to handle if any fields are left empty
		if (passedEmployeeID.equals("") || passedFirstName.equals("") || passedLastName.equals("")
				|| passedManagerial.equals("")) {
			return;
		}
		pstmt.executeQuery();
		conn.close();
	}

	public static void addToInventory(Product product) throws SQLException {
		PreparedStatement pstmt;
		String passedName = product.getSetName();
		String passedPrice = product.getPrice();
		String passedQuantity = product.getQuantity();
		String passedItemNumber = product.getItemNumber();
		String passedDate = product.getDate();
		ResultSet rs;
		Connection conn = connection();

		pstmt = conn.prepareStatement("SELECT ITEM_# FROM PRODUCT WHERE ITEM_# = '" + passedItemNumber + "'");
		rs = pstmt.executeQuery();

		if (rs.next() == true) {
			updateInventoryItemAdding(
					new Product(passedName, passedPrice, passedQuantity, passedItemNumber, passedDate));
		} else {
			pstmt = conn.prepareStatement(
					"INSERT INTO PRODUCT(SET_NAME, PRICE, QUANTITY, ITEM_#, LAST_RECEIVED) " + "VALUES (?,?,?,?,?)");
			pstmt.setString(1, passedName);
			pstmt.setString(2, passedPrice);
			pstmt.setString(3, passedQuantity);
			pstmt.setString(4, passedItemNumber);
			pstmt.setString(5, passedDate);
			// Logic to handle hitting cancel and not submitting anything
			if (passedName.equals("") || passedPrice.equals("") || passedQuantity.equals("")
					|| passedItemNumber.equals("")) {
				return;
			}
			pstmt.executeUpdate();
		}
		conn.close();
	}

	public static void updateInventoryItemAdding(Product product) throws SQLException {
		PreparedStatement pstmt;
		Connection conn = connection();

		pstmt = conn.prepareStatement("UPDATE PRODUCT SET QUANTITY = QUANTITY + '" + product.getQuantity()
				+ "', PRICE = '" + product.getPrice() + "', LAST_RECEIVED = '" + product.getDate()
				+ "' WHERE ITEM_# = '" + product.getItemNumber() + "'");
		pstmt.executeUpdate();

		conn.close();
	}

	static void deleteSet(int setNum) throws SQLException {
		PreparedStatement pstmt;
		Connection conn = connection();

		pstmt = conn.prepareStatement("DELETE FROM PRODUCT WHERE ITEM_# = '" + setNum + "'");
		pstmt.executeUpdate();

		conn.close();
	}

	static void deleteEmployee(String employeeID) throws SQLException {
		PreparedStatement pstmt;
		Connection conn = connection();

		pstmt = conn.prepareStatement("DELETE FROM EMPLOYEE WHERE EMPLOYEEID = '" + employeeID + "'");
		pstmt.executeUpdate();

		conn.close();
	}

	static DefaultTableModel retrieveEmployees() throws SQLException {
		DefaultTableModel model = new DefaultTableModel();
		Connection conn = connection();
		PreparedStatement pstmt;
		ResultSet rs;
		String employeeID;
		String firstName;
		String lastName;
		String managerial;
		// receive it as 1/0
		int managerialRaw;
		JTable employeeTable = new JTable(model) {
			public boolean editCellAt(int row, int column, java.util.EventObject e) {
				return false;
			}
		};

		pstmt = conn.prepareStatement("SELECT * FROM EMPLOYEE");

		rs = pstmt.executeQuery();

		// initializing columns
		model.addColumn("employeeID");
		model.addColumn("First Name");
		model.addColumn("Last Name");
		model.addColumn("Managerial");

		while (rs.next()) {
			employeeID = rs.getString(1);
			firstName = rs.getString(2);
			lastName = rs.getString(3);
			managerial = rs.getString(4);
			if (Integer.parseInt(managerial) == 1) {
				managerial = "Y";
			} else {
				managerial = "N";
			}
			model.addRow(new Object[] { employeeID, firstName, lastName, managerial });
		}
		conn.close();
		return model;
	}

	public static DefaultTableModel retrieveInventory() throws SQLException {
		ResultSet rs;
		String setName;
		String setID;
		double price;
		int quantity;
		String date;
		Connection conn = connection();
		DefaultTableModel model = new DefaultTableModel();
		JTable inventoryTable = new JTable(model) {
			public boolean editCellAt(int row, int column, java.util.EventObject e) {
				return false;
			}
		};

		// simply grabs all (*) because we want to display all of our inventory.
		PreparedStatement retrieveInventory = conn.prepareStatement("SELECT * FROM PRODUCT");

		rs = retrieveInventory.executeQuery();

		// Initializing column names
		model.addColumn("Set Name");
		model.addColumn("Item #");
		model.addColumn("Price (USD$)");
		model.addColumn("Quantity");
		model.addColumn("Last Received On");

		while (rs.next()) {
			setName = rs.getString(1);
			setID = rs.getString(4);
			price = Double.parseDouble(rs.getString(2));
			quantity = Integer.parseInt(rs.getString(3));
			date = rs.getString(5);
			model.addRow(new Object[] { setName, setID, price, quantity, date });
		}
		conn.close();
		return model;
		// return table;
	}

	public static Boolean uniqueUsernameAndSsn(String passedUsername, String employeeID) throws SQLException {
		Boolean isUnique = false;
		ResultSet rs;
		Connection conn = connection();

		// SQL statement that grabs the password in the database of the particular user
		// that is taken from the signin page.
		PreparedStatement pstmt = conn
				.prepareStatement("SELECT USERNAME FROM LOGIN WHERE USERNAME= '" + passedUsername + "'");

		rs = pstmt.executeQuery();

		if (rs.next()) {
			isUnique = false;
		} else {
			/**
			 * Not too sure how to do this more concisely in SQL but what is happening is if
			 * rs.next from the if above has next then the uniqueness is definitely not true
			 * because it has a result set that it returns. However, if it does not have a
			 * next then we run a new SQL query where we check if the ssn which is entered
			 * from the program matches an ssn from the employee table then we evaluate if
			 * that is there we look at another query where we check if that particular ssn
			 * is also in the login table which we will then doubly check if it is unique
			 * here and there.
			 */
			pstmt = conn.prepareStatement("SELECT EMPLOYEEID FROM EMPLOYEE WHERE EMPLOYEEID ='" + employeeID + "'");
			rs = pstmt.executeQuery();
			if (rs.next()) {
				pstmt = conn.prepareStatement("SELECT EMPLOYEE FROM LOGIN WHERE EMPLOYEE ='" + employeeID + "'");
				rs = pstmt.executeQuery();
				if (rs.next()) {
					isUnique = false;
				} else {
					isUnique = true;
				}
			}
		}
		conn.close();
		return isUnique;
	}

	static Boolean getLogin(String passedUsername, String passedPassword) throws SQLException {
		ResultSet rs;
		Boolean isPasswordValid = false;
		String password = "";
		Connection conn = connection();

		// SQL statement that grabs the password in the database of the particular user
		// that is taken from the signin page.
		PreparedStatement pstmt = conn
				.prepareStatement("SELECT PASSWORD FROM LOGIN WHERE USERNAME= '" + passedUsername + "'");

		rs = pstmt.executeQuery();

		// Have rs.next as an if statement so that if the query turns up with nothing
		// then we do not crash the program.
		if (rs.next()) {
			password = rs.getString(1);// actually grabs the password
		}

		// the password that is typed in is compared to the password in the database and
		// sets the boolean to true or false depending on that
		if (passedPassword.equals(password)) {
			isPasswordValid = true;
		}

		conn.close();
		return isPasswordValid;
	}

	public static void insertLogin(String employeeID, String passedUsername, String passedPassword)
			throws SQLException {
		ResultSet rs;
		Connection conn = connection();

		// SQL statement that grabs the password in the database of the particular user
		// that is taken from the signin page.
		PreparedStatement pstmt = conn.prepareStatement("INSERT INTO LOGIN(EMPLOYEE, USERNAME, PASSWORD) " + "VALUES (?,?,?)");
		pstmt.setString(1, employeeID);
		pstmt.setString(2, passedUsername);
		pstmt.setString(3, passedPassword);
		pstmt.executeUpdate();
		conn.close();
	}

	public static Connection connection() throws SQLException {
		String uid = "G28";
		String pword = "bHCUs0R11";
		String url = "jdbc:oracle:thin:@cisvm-oracle.unfcsd.unf.edu:1521:orcl";

		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

		Connection conn = DriverManager.getConnection(url, uid, pword);
		return conn;
	}
}
