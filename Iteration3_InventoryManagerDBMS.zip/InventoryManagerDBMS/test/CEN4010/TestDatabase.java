package CEN4010;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class TestDatabase {
	
	ResultSet rs;
	Connection conn;
	PreparedStatement pstmt;
	String setNumber;
	
	Connection connection() throws SQLException{
		String uid = "G28";
		String pword = "bHCUs0R11";
		String url = "jdbc:oracle:thin:@cisvm-oracle.unfcsd.unf.edu:1521:orcl";
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection conn = DriverManager.getConnection(url, uid, pword);
		return conn;
	}
	@Test
	void testLogin() {
		try {
			Connection conn = connection();
		} catch (SQLException e) {
			fail("Failed to connect");
		}
	}
	//Tests from this point are developed without access to the database make sure to check it after.
	@ParameterizedTest
	@ValueSource(strings = {"10330"})
	void testRetrieveSetInfo(String setNumber) throws SQLException{
		conn = connection();
		pstmt = conn.prepareStatement("SELECT * FROM PRODUCT WHERE ITEM_# = '"+setNumber+"'");
		rs = pstmt.executeQuery();
		int expectedSetNumber = Integer.parseInt(setNumber);
		int actualSetNumber = 0;
		if(rs.next()==false) {
			fail("No items retrieved, query failed");
		}
		else {
			actualSetNumber = Integer.parseInt(rs.getString(4));
		}
		assertEquals(expectedSetNumber, actualSetNumber);
		conn.close();
	}
	/**
	 * 
	 * This method will test if the user is managerial from the login to verify if the user should be able to see the employee panel option or not
	 * 
	 * @param username
	 * @throws SQLException
	 */
	@ParameterizedTest
	@ValueSource(strings = {"brian"})
	void testIsAdmin(String username) throws SQLException {
		Boolean actual;
		Boolean expected;
		conn = connection();
		pstmt = conn.prepareStatement("SELECT MANAGERIAL FROM EMPLOYEE INNER JOIN LOGIN ON EMPLOYEE.EMPLOYEEID = LOGIN.EMPLOYEE WHERE LOGIN.USERNAME = '"+username+"'");
		rs = pstmt.executeQuery();
		actual = (Boolean) rs.next();
		expected = true;
		assertEquals(actual, expected);
		conn.close();
	}
	
	/**
	 * 
	 * This method like the one previous, will test if the managerial boolean represented as a number in the system (0,1) retrieves the current value for a certain 
	 * employee through their ssn.
	 * 
	 * @param ssn is the social security number of the employee
	 * @throws SQLException
	 */
	@ParameterizedTest
	@ValueSource(strings = {"000000"})
	void testRetrieveEmployee(String employeeID) throws SQLException {
		Employee actual;
		Employee expected;
		conn = connection();
		pstmt = conn.prepareStatement("SELECT * FROM EMPLOYEE WHERE EMPLOYEEID = '"+employeeID+"'");
		rs = pstmt.executeQuery();
		rs.next();
		System.out.println(rs.getString(1));
		System.out.println(rs.getString(2));
		System.out.println(rs.getString(3));
		System.out.println(rs.getString(4));

		actual = new Employee(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4));
		expected = new Employee("000000","guest","guest","0");
		assertEquals(actual.employeeID, expected.employeeID);
		conn.close();
	}
	
	@Test
	void testView() throws SQLException {
		CustomJFrame frame = new CustomJFrame();
	}
	
	@Test
	void testCreateEmployee() throws SQLException {
		Employee testEmployee = new Employee("147878","Brian","Dinh","Y");
		Boolean expected = true;
		Boolean actual = false;
		conn = connection();
		Database.addEmployee(testEmployee);
		pstmt = conn.prepareStatement("SELECT * FROM EMPLOYEE WHERE EMPLOYEE ID ='"+testEmployee.employeeID+"'");
		rs = pstmt.executeQuery();
		if(rs.next()==true) {
			actual = true;
		}
		assertEquals(expected,actual);
		conn.close();
	}
	
	@Test
	void testDeleteEmployee() throws SQLException {
		Boolean expected = false;
		Boolean actual = true;
		conn = connection();
		Database.deleteEmployee("147878");
		pstmt = conn.prepareStatement("SELECT * FROM EMPLOYEE WHERE EMPLOYEE ID ='"+"147878"+"'");
		rs = pstmt.executeQuery();
		if(rs.next()==false) {
			actual = false;
		}
		assertEquals(expected,actual);
		conn.close();
	}
}
