package CEN4010;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

public class CustomJFrame extends JFrame {
	// IMPORTANT: ANY COMMENTED OUT CODE IS MOST LIKELY FOR THE SCENARIO OF IF WE DO
	// AN EVENT PLANNER PROGRAM
	private HashMap<String, String> loginCredentials = new HashMap<>();
	private JPanel cards;
	private JPanel signInPanel;
	private JPanel employeesPanelAdmin;
	private JPanel inventoryPanel;
	private JPanel signUpPanel;
	private JPanel homePanel;
	private JPanel addSetPanel;
	private JPanel inventoryPanelAdmin;
	// These elements are for the sign in panel
	private JButton signInBtn = new JButton("Sign in");
	// These elements are for the inventoryPanel
	private JButton addSetBtn = new JButton("Add/Update");
	private JScrollPane queriedInventoryScrollPane;
	private JTable queriedInventory = new JTable();
	private DefaultTableModel model;
	// These elements are for the employees which is now only going to be in admin
	private JScrollPane queriedEmployeesScrollPane;
	private JTable queriedEmployees = new JTable();
	private JButton addEmployeeBtn = new JButton("Add Employee");
	private JButton addAdminBtn = new JButton("Add Manager");
	private JButton deleteEmployeeBtn = new JButton("Delete");
	private JButton updateEmployeeBtn = new JButton("Update");
	// These elements are for the signup page
	private JButton signUpBtn = new JButton("Sign Up"); // make sure that this button takes to home page!
	private JButton createAccountBtn = new JButton("Sign Up");
	private JButton cancelBtn = new JButton("Cancel");
	// These elements are for the inventoryPanel in admin view
	private DefaultTableModel adminInventoryModel;
	private JScrollPane queriedInventoryAdminScrollPane;
	private JTable queriedInventoryAdmin = new JTable();
	private JButton addSetBtnAdmin = new JButton("Add/Update");
	private JButton deleteBtnAdmin = new JButton("Delete Row");
	//Generic model for action listeners
	DefaultTableModel updateModel = new DefaultTableModel();
	//JFrame icon
//	ImageIcon legoIcon = new ImageIcon(getClass().getClassLoader().getResource("LegoIcon.png"));
		
	public CustomJFrame() throws SQLException {
		// Initializing all the panels
		JFrame frame = new JFrame("Lego Inventory DBMS");
		cards = new JPanel(new CardLayout());
		signInPanel = new JPanel();
		employeesPanelAdmin = new JPanel();
		homePanel = new JPanel();
		signUpPanel = new JPanel();
		inventoryPanel = new JPanel();
		addSetPanel = new JPanel();
		inventoryPanelAdmin = new JPanel();
		JLabel usernameLabel = new JLabel("Username: ");
		JLabel passwordLabel = new JLabel("Password: ");
		JLabel employeeIDLabelSignUp = new JLabel("Employee ID: ");
		JLabel usernameLabelSignUp = new JLabel("Username: ");
		JLabel passwordLabelSignUp = new JLabel("Password: ");
		JTextField ssnFieldSignUp = new JTextField();
		JTextField usernameFieldSignUp = new JTextField();
		JTextField usernameField = new JTextField();
		JPasswordField passwordFieldSignUp = new JPasswordField();
		JPasswordField passwordField = new JPasswordField();
		// These error messages are specifically for use on the sign up page
		JLabel errorMessageSignUpLength = new JLabel(
				"The username AND password must both be individually under 20 characters long");
		JLabel errorMessageSignUpUnique = new JLabel("The username MUST be unique, please choose a new one");
		JLabel errorMessage = new JLabel("Incorrect username or password please try again");
		GridBagConstraints gbc = new GridBagConstraints();
		JScrollPane homeScrollPane = new JScrollPane();
		// JTable queriedInventory;
		CardLayout cl = (CardLayout) cards.getLayout();

		loginCredentials.put("brian", "brianpass");
		loginCredentials.put("user", "pass");

		// JMenuBar Code regular view
		JMenuBar menuBar = new JMenuBar();
		JMenu navigate = new JMenu("Navigate");
		JMenuItem home = new JMenuItem("Home");
		JMenuItem inventory = new JMenuItem("Inventory");
		JMenuItem signOut = new JMenuItem("Sign out");
		//	JMenuItem employee = new JMenuItem("Employee"); //Should not have this in view
		menuBar.add(navigate);
		home.setName("Home Page");

		// JMenuBar Code for admin view
		JMenuBar menuBarAdmin = new JMenuBar();
		JMenu navigateAdmin = new JMenu("Navigate");
		JMenuItem homeAdmin = new JMenuItem("Home");
		JMenuItem inventoryAdmin = new JMenuItem("Inventory");
		JMenuItem employeeAdmin = new JMenuItem("Employee");
		JMenuItem signOutAdmin = new JMenuItem("Sign out");
		menuBarAdmin.add(navigateAdmin);

		// JMenuBar actionlisteners for regular view
		home.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Home Page");
			}
		});
		inventory.setName("Inventory Page");
		inventory.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Inventory Page");
			}
		});
		signOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Sign-in Page");
			}
		});
		
		// JMenuBar actionlisteners for admin view
		employeeAdmin.setName("Employees Page");
		employeeAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {		
				cl.show(cards, "Employees Page");
			}
		});
		inventoryAdmin.setName("Admin Inventory Page");
		inventoryAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Inventory Admin Page");
			}
		});
		signOutAdmin.setName("Sign Out Admin");
		signOutAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Sign-in Page");
				menuBarAdmin.setVisible(false);
			}
		});
		homeAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Home Page");
			}
		});
		navigate.add(home);
		navigate.add(inventory);
		navigate.add(signOut);

		navigateAdmin.add(homeAdmin);
		navigateAdmin.add(employeeAdmin);
		navigateAdmin.add(inventoryAdmin);
		navigateAdmin.add(signOutAdmin);

		// adding all panels to the cardslayout panel
		cards.add(signInPanel, "Sign-in Page");
		cards.add(signUpPanel, "Sign-up Page");
		cards.add(employeesPanelAdmin, "Employees Page");
		cards.add(inventoryPanel, "Inventory Page");
		cards.add(homePanel, "Home Page");
		cards.add(inventoryPanelAdmin, "Inventory Admin Page");

		//Adding all button listeners here
		signInBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CardLayout cl = (CardLayout) cards.getLayout();
				try {
					if (Database.getLogin(usernameField.getText(), String.valueOf(passwordField.getPassword()))
							&& Database.isAdmin(usernameField.getText())) {
						cl.show(cards, "Home Page");
						errorMessage.setVisible(false);
						frame.setJMenuBar(menuBarAdmin);
						menuBarAdmin.setVisible(true);
					} else if (Database.getLogin(usernameField.getText(), String.valueOf(passwordField.getPassword()))
							&& Database.isAdmin(usernameField.getText()) == false) {
						cl.show(cards, "Home Page");
						errorMessage.setVisible(false);
						frame.setJMenuBar(menuBar);
						menuBar.setVisible(true);
					} else {
						errorMessage.setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//Just in case, sets the fields to empty so no one can see
				usernameField.setText("");
				passwordField.setText("");
			}
		});
		signUpBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// CardLayout cl = (CardLayout) cards.getLayout();
				try {
					// If the user or pass is longer than 20 characters
					if (usernameFieldSignUp.getText().length() > 20
							|| String.valueOf(passwordField.getPassword()).length() > 20) {
						errorMessageSignUpLength.setVisible(true);
						errorMessageSignUpUnique.setVisible(false);
					}
					// If the user name is unique then we sign them up here
					else if (Database.uniqueUsernameAndSsn(usernameFieldSignUp.getText(), ssnFieldSignUp.getText())) {
						errorMessageSignUpLength.setVisible(false);
						errorMessageSignUpUnique.setVisible(false);
						Database.insertLogin(ssnFieldSignUp.getText(), usernameFieldSignUp.getText(),
								String.valueOf(passwordFieldSignUp.getPassword()));
						frame.setJMenuBar(menuBar);
						menuBar.setVisible(true);
						cl.show(cards, "Home Page");
					}
					// If the username is not unique
					else if (Database.uniqueUsernameAndSsn(usernameFieldSignUp.getText(),
							ssnFieldSignUp.getText()) == false) {
						errorMessageSignUpLength.setVisible(false);
						errorMessageSignUpUnique.setVisible(true);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		createAccountBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Sign-up Page");
			}
		});
		cancelBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, "Sign-in Page");
			}
		});
		addSetBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField setNameField = new JTextField();
				JTextField setPriceField = new JTextField();
				JTextField quantityField = new JTextField();
				JTextField itemNumberField = new JTextField();
				Format dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				Date todaysDate = Calendar.getInstance().getTime();
				String date = dateFormatter.format(todaysDate);

				Object[] fields = { "Set Name: ", setNameField, "Set Price: ", setPriceField, "Quantity Received: ",
						quantityField, "Item Number: ", itemNumberField };
				JOptionPane.showConfirmDialog(null, fields, "Add Item", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

				try {
					Database.addToInventory(new Product(setNameField.getText(), setPriceField.getText(), quantityField.getText(),
							itemNumberField.getText(), date));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					gbc.gridx = 2;
					gbc.gridy = 0;
					gbc.gridheight = 2;
					//					DefaultTableModel model = (DefaultTableModel) queriedInventory.getModel();
					//					model.setRowCount(0);
					updateModel = Database.retrieveInventory();
					queriedInventory.setModel(updateModel);
					inventoryPanel.add(queriedInventoryScrollPane, gbc);
					queriedInventoryAdmin.setModel(updateModel);
					inventoryPanelAdmin.add(queriedInventoryAdmin);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});
		addSetBtnAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField setNameField = new JTextField();
				JTextField setPriceField = new JTextField();
				JTextField quantityField = new JTextField();
				JTextField itemNumberField = new JTextField();
				Format dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				Date todaysDate = Calendar.getInstance().getTime();
				String date = dateFormatter.format(todaysDate);

				Object[] fields = { "Set Name: ", setNameField, "Set Price: ", setPriceField, "Quantity Received: ",
						quantityField, "Item Number: ", itemNumberField };
				JOptionPane.showConfirmDialog(null, fields, "Add Item", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

				try {
					Database.addToInventory(new Product(setNameField.getText(), setPriceField.getText(), quantityField.getText(),
							itemNumberField.getText(), date));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					updateModel = Database.retrieveInventory();
					queriedInventoryAdmin.setModel(updateModel);
					inventoryPanelAdmin.add(queriedInventoryAdminScrollPane, gbc);
					queriedInventory.setModel(updateModel);
					inventoryPanel.add(queriedInventoryScrollPane, gbc);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});
		deleteBtnAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = queriedInventoryAdmin.getSelectedRow();
				if(row!=-1) {
				int column = 1;
				//My thinking is that if we parse the string for the int we do not need to override to string and we can reconvert to string
//				String rowValue = Integer.parseInt(queriedInventoryAdmin.getValueAt(row, column).toString());
				int rowValue = Integer.parseInt(queriedInventoryAdmin.getValueAt(row, column).toString());
				try {
					Database.deleteSet(rowValue);
					updateModel = Database.retrieveInventory();
					queriedInventoryAdmin.setModel(updateModel);
					inventoryPanelAdmin.add(queriedInventoryAdminScrollPane, gbc);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			}
		});
		addEmployeeBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JTextField firstNameField = new JTextField();
				JTextField lastNameField = new JTextField();
				JTextField employeeIDField = new JTextField();
				JTextField managerialField = new JTextField();
				
				Object[] fields = {"First Name: ", firstNameField, "Last Name: ", lastNameField, "Employee ID: ", employeeIDField, "Manager (Y/N)", managerialField};
				
				JOptionPane.showConfirmDialog(null, fields, "Add Employee", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
				try {
					if(managerialField.getText()=="Y") {
						Database.addEmployee(new Manager(employeeIDField.getText(), firstNameField.getText(), lastNameField.getText(), managerialField.getText()));
					} else {
					Database.addEmployee(new Employee(employeeIDField.getText(), firstNameField.getText(), lastNameField.getText(), managerialField.getText()));
					}
					updateModel = Database.retrieveEmployees();
					queriedEmployees.setModel(updateModel);
					employeesPanelAdmin.add(queriedEmployeesScrollPane);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

		});
		deleteEmployeeBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = queriedEmployees.getSelectedRow();
				if(row!=-1) {
					int column = 0;
					String rowValue = queriedEmployees.getValueAt(row, column).toString();
					try {
						Database.deleteEmployee(rowValue);
						updateModel = Database.retrieveEmployees();
						queriedEmployees.setModel(updateModel);
						employeesPanelAdmin.add(queriedEmployeesScrollPane);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					
				}
			}
		});
		// Hard coding sign in panel because it doesn't need much structure or buttons
		// to it.
		signInPanel.setLayout(null);
		usernameLabel.setBounds(300, 225, 100, 25);
		usernameField.setBounds(300, 250, 200, 25);
		passwordLabel.setBounds(300, 275, 100, 25);
		passwordField.setBounds(300, 300, 200, 25);
		signInBtn.setBounds(350, 350, 100, 50);
		createAccountBtn.setBounds(350, 400, 100, 50);
		errorMessage.setForeground(Color.red);
		errorMessage.setBounds(250, 400, 400, 25);
		errorMessage.setVisible(false);
		signInPanel.add(usernameLabel);
		signInPanel.add(passwordLabel);
		signInPanel.add(usernameField);
		signInPanel.add(passwordField);
		signInPanel.add(errorMessage);
		// Button that allows user to sign in if a verified employee
		// Add an if check later for how we decided to see if the person is an employee
		// or not
		signInPanel.add(createAccountBtn);
		signInPanel.add(signInBtn);

		// Hard coding sign up panel as well
		signUpPanel.setLayout(null);
		employeeIDLabelSignUp.setBounds(300, 175, 100, 25);
		ssnFieldSignUp.setBounds(300, 200, 200, 25);
		usernameLabelSignUp.setBounds(300, 225, 100, 25);
		usernameFieldSignUp.setBounds(300, 250, 200, 25);
		passwordLabelSignUp.setBounds(300, 275, 100, 25);
		passwordFieldSignUp.setBounds(300, 300, 200, 25);
		signUpBtn.setBounds(400, 350, 100, 50);
		cancelBtn.setBounds(300, 350, 100, 50);
		errorMessageSignUpLength.setForeground(Color.red);
		errorMessageSignUpUnique.setForeground(Color.red);
		errorMessageSignUpLength.setBounds(250, 400, 400, 25);
		errorMessageSignUpUnique.setBounds(250, 430, 400, 25);
		errorMessageSignUpUnique.setVisible(false);
		errorMessageSignUpLength.setVisible(false);
		signUpPanel.add(employeeIDLabelSignUp);
		signUpPanel.add(ssnFieldSignUp);
		signUpPanel.add(usernameLabelSignUp);
		signUpPanel.add(usernameFieldSignUp);
		signUpPanel.add(passwordLabelSignUp);
		signUpPanel.add(passwordFieldSignUp);
		signUpPanel.add(errorMessageSignUpUnique);
		signUpPanel.add(errorMessageSignUpLength);
		signUpPanel.add(cancelBtn);
		signUpPanel.add(signUpBtn);

		// Adding all buttons for the home page
		homePanel.setLayout(new GridBagLayout());

		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.PAGE_START;
		JLabel welcomeLabel = new JLabel("Welcome to the inventory DBMS!");
		Border welcomeBorder = BorderFactory.createRaisedBevelBorder();
		welcomeLabel.setBorder(welcomeBorder);
		homePanel.add(welcomeLabel, gbc);

		inventoryPanel.setLayout(new GridBagLayout());
		inventoryPanelAdmin.setLayout(new GridBagLayout());
		employeesPanelAdmin.setLayout(new GridBagLayout());
		
		
//		Commented out for now but will remove it after to review how gui looks w no database
		DefaultTableModel model = Database.retrieveInventory();
		queriedInventory.setModel(model);
		queriedInventoryScrollPane = new JScrollPane(queriedInventory);
		queriedInventoryScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		// Regular view inventory panel
		gbc.anchor = GridBagConstraints.FIRST_LINE_START;
		gbc.gridx = 0;
		gbc.gridy = 0;
		inventoryPanel.add(addSetBtn, gbc);
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.gridheight = 4;
		inventoryPanel.add(queriedInventoryScrollPane, gbc);

		// Admin view inventory panel
		DefaultTableModel adminInventoryModel = Database.retrieveInventory();
		queriedInventoryAdmin.setModel(model);
		queriedInventoryAdminScrollPane = new JScrollPane(queriedInventoryAdmin);
		queriedInventoryAdminScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		JPanel inventoryAdminBtnPanel = new JPanel();
		GridBagConstraints adminBtnGbc = new GridBagConstraints();
		
		inventoryAdminBtnPanel.setLayout(new GridBagLayout());
		adminBtnGbc.gridx = 0;
		adminBtnGbc.gridy = 0;
		inventoryAdminBtnPanel.add(addSetBtnAdmin, adminBtnGbc);
		adminBtnGbc.gridx = 0;
		adminBtnGbc.gridy = 1;
		inventoryAdminBtnPanel.add(deleteBtnAdmin, adminBtnGbc);
		gbc.gridx = 0;
		gbc.gridy = 0;
		inventoryPanelAdmin.add(inventoryAdminBtnPanel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 0;
		gbc.gridheight = 4;
		inventoryPanelAdmin.add(queriedInventoryAdminScrollPane, gbc);


		// Setting up how employees admin panel looks
		DefaultTableModel employeeModel = Database.retrieveEmployees();
		queriedEmployees.setModel(employeeModel);
		queriedEmployeesScrollPane = new JScrollPane(queriedEmployees);
		queriedEmployeesScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		JPanel employeesPanelAdminBtnPanel = new JPanel();
		GridBagConstraints employeeBtnGbc = new GridBagConstraints();
		employeesPanelAdminBtnPanel.setLayout(new GridBagLayout());
		employeesPanelAdmin.setLayout(new GridBagLayout());
		employeeBtnGbc.gridx = 0;
		employeeBtnGbc.gridy = 0;
		employeesPanelAdminBtnPanel.add(addEmployeeBtn, employeeBtnGbc);
		employeeBtnGbc.gridx = 0;
		employeeBtnGbc.gridy = 1;
		employeesPanelAdminBtnPanel.add(deleteEmployeeBtn, employeeBtnGbc);
		gbc.gridx = 0;
		gbc.gridy = 0; 
		employeesPanelAdmin.add(employeesPanelAdminBtnPanel, gbc);
		gbc.gridx = 2;
		gbc.gridy = 0;
		employeesPanelAdmin.add(queriedEmployeesScrollPane, gbc);

		frame.getContentPane().add(cards);
		frame.pack();
		frame.setSize(800, 800);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
