package CEN4010;

public class Product {
	protected String setName;
	protected String price;
	protected String quantity;
	protected String itemNumber;
	protected String date;
	
	Product(String setName, String price, String quantity, String itemNumber, String date) {
		this.setName = setName;
		this.price = price;
		this.quantity = quantity;
		this.itemNumber = itemNumber;
		this.date = date;
	}

	public String getSetName() {
		return setName;
	}

	public String getPrice() {
		return price;
	}

	public String getQuantity() {
		return quantity;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public String getDate() {
		return date;
	}

}
